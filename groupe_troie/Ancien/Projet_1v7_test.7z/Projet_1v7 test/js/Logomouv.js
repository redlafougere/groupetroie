let x;
let y;

let xspeed;
let yspeed;

let jura;

function preload() {
    jura = loadImage('JurassicParkLogo.png');  
}

function setup() {
    createCanvas(windowWidth,windowHeight);
    x = random(width);
    y= random(height);
    xspeed = 10;
    yspeed = 10;

}

function draw() {
    background(0);
    image(jura, x, y);

    x = x + xspeend;
    y = y + yspeed;

    if (x + jura.width >= width) {
        xspeed = -xspeed;
        x = width - jura.width;
    } else if (x <= 0) {
        xspeed = -xspeed;
        x = 0;
    }

    if (y + jura.height >= height) {
        yspeed == -yspeed;
        y = height - jura.height;
    } else if (y <= 0) {
        yspeed = -yspeed;
        y = 0;
    }
}

